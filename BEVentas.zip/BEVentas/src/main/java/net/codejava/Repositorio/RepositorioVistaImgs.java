package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.VistaImgs;

public interface RepositorioVistaImgs extends CrudRepository<VistaImgs, Integer>{

}
