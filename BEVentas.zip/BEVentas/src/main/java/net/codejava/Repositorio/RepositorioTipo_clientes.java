package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;
import net.codejava.Entidad.Tipo_clientes;

public interface RepositorioTipo_clientes extends CrudRepository<Tipo_clientes, Integer>{

}
