package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.Fichas_clientes;

public interface RepositorioFicha_clientes extends CrudRepository< Fichas_clientes, Integer> {

}
