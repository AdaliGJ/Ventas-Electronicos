package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.Marcas;

public interface RepositorioMarcas extends CrudRepository< Marcas, Integer>{

}
