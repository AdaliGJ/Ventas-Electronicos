package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;
import net.codejava.Entidad.Tipo_usuarios;

public interface RepositorioTipo_usuarios extends CrudRepository<Tipo_usuarios, Integer>{

}
