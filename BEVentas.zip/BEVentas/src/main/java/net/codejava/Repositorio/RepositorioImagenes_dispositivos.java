package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;
import net.codejava.Entidad.Imagenes_dispositivos;

public interface RepositorioImagenes_dispositivos extends CrudRepository< Imagenes_dispositivos, Integer>{

}
