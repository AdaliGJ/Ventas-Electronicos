package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;
import net.codejava.Entidad.Ventas;

public interface RepositorioVentas extends CrudRepository<Ventas, Integer>{

}
