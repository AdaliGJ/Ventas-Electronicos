package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.Smartwatch;

public interface RepositorioSmartwatch extends CrudRepository< Smartwatch, Integer>{

}
