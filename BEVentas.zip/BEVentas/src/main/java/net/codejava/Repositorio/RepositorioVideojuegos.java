package net.codejava.Repositorio;


import org.springframework.data.repository.CrudRepository;
import net.codejava.Entidad.Videojuegos;



public interface RepositorioVideojuegos extends CrudRepository<Videojuegos, Integer>{
	


}