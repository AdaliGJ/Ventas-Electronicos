package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.Marcas;



public interface MarcaServiceApi extends CrudRepository<Marcas, Integer>{
	


}
