package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.VistaInfoCliente;

public interface RepositorioVistaInfoCliente extends CrudRepository<VistaInfoCliente, Integer>{

}
