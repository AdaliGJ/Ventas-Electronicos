package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;
import net.codejava.Entidad.Inventario;

public interface RepositorioInventario extends CrudRepository< Inventario, Integer>{

}
