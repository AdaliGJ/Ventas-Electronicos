package net.codejava.Repositorio;

import org.springframework.data.repository.CrudRepository;

import net.codejava.Entidad.Ordenes_compra;

public interface RepositorioOrdenes_compra extends CrudRepository< Ordenes_compra, Integer>{

}
