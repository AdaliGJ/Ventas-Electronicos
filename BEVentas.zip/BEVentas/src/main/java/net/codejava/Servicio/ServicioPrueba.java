package net.codejava.Servicio;

import org.springframework.stereotype.Service;

import antlr.collections.List;

@Service 
public class ServicioPrueba<Prueba> {


	
	
}
