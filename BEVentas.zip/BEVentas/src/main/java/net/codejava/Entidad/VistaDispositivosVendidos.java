package net.codejava.Entidad;

public class VistaDispositivosVendidos {

}
